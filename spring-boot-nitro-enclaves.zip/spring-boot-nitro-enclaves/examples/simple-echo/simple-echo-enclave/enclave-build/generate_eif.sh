#!/bin/bash -e

nitro-cli build-enclave --docker-uri public.ecr.aws/s0k4s5w7/enclave-wallet --output-file bin/enclave-wallet.eif