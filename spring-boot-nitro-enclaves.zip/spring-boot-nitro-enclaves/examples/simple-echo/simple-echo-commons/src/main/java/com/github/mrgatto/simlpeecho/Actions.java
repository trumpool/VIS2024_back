package com.github.mrgatto.simlpeecho;

public enum Actions {

	ECHO;

}
