#!/bin/sh
# Assign an IP address to local loopback

java -Djava.library.path=/usr/lib/prebuild-libs -jar /app/app.jar

