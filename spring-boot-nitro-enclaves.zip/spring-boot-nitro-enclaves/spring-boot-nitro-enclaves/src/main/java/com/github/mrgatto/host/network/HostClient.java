package com.github.mrgatto.host.network;

public interface HostClient {

	public byte[] send(byte[] content);

}
